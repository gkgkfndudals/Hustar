package com.example.myviewpagerfinal;

import android.os.Bundle;

public interface FragmentCallback {
    public void onFragmentSelected(int position, Bundle bundle);
}
